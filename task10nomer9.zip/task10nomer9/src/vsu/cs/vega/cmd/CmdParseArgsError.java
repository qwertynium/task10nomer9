package vsu.cs.vega.cmd;

public class CmdParseArgsError extends Exception {

}

